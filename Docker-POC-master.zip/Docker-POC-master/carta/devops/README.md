usage: carta-devops <commands>

Hello and welcome to the test.

  carta-devops help      This menu
  carta-devops serve     Serves the app
  carta-devops test      Tests the app
  carta-devops tasks     What is expected of you
